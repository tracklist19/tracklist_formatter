1. WebPage speichern (HTML-only) , Benennung egal
   -> HTML-File muss ArbeitsOrdner des Programms liegen und sollte die einzig-dortBefindliche HTML-File sein 
   -> Der Ort des ArbeitsOrdners ist für die Funktion des Programms nicht wichtig 
2. Programm ausführen : per_Doppelklick oder markieren&ENTER 
3. Output-TXT-File wird geöffnet, sie enthält die Tracklist im gewünschten Format, 
	diese kann nun herauskopiert werden [-> STRG+A -> STRG+C]
4. Nach dem Kopieren das Programm-Fenster aufrufen 
   -> Dort ENTER drücken: Durch das Programm wird 
			  > das Output-TXT-Fenster geschlossen 
			    (falls du es vorher selbst schließt: ist auch Ok) 
			  > und anschließend die Output-TXT-File und die HTML-File (->je nach Eingabe) gelöscht 

Stand : > Funktioniert derzeit nur für Album-Tracklists, nicht für Sampler-Tracklists (->hier werden nur die 
							 title erkannt, nicht die artists) 
	> Funktioniert derzeit nur für ReleaseEntry-HTMLs [discogs.com/release/...], 
			noch nicht für  MasterEntry-HTMLs [discogs.com/master/...]
